﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
         Random rnd1;
        public Form1()
        {
            InitializeComponent();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            int WhereX = rnd1.Next(1, this.groupBox2.Size.Width - button1.Size.Width);
            int WhereY = rnd1.Next(15, this.groupBox2.Size.Height - button1.Size.Height);
            button1.Location = new System.Drawing.Point( WhereX, WhereY);
        }
       
        private void groupBox2_Click(object sender, System.EventArgs e)
        {
            if (textBox1.Text.Length == 0) textBox1.Text += 1;
            else textBox1.Text = "" + (1 + ulong.Parse(textBox1.Text));
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            rnd1 = new Random();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.timer1.Enabled = false;           
            this.textBox1.Text = "";
            this.timer1.Enabled = true;
            this.ControlBox = true;
        }
        private void Form1_Shown(object sender, EventArgs e)
        {
            MessageBox.Show("Catch C# if you can!" );
            this.timer1.Enabled = true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Interval = timer1.Interval -1;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Interval = timer1.Interval  + 10;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
